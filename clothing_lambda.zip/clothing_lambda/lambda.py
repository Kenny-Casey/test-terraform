import boto3
import json
import logging
from botocore.exceptions import ClientError
from score_outfit import score_outfit, extract_labels_from_rekognition

logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_image_labels(rekognition, img_bytes):
    logger.info("got to get_image_labels")
    try:
        # print(rekognition.detect_labels(Image={'Bytes': img_bytes}, Features=['GENERAL_LABELS']))
        response = rekognition.detect_labels(
            Image={'Bytes': img_bytes},
            Features=['GENERAL_LABELS'],
            MinConfidence=60,
            Settings={
                'GeneralLabels': {
                    'LabelCategoryInclusionFilters': ['Apparel and Accessories']
                }
            }
        )
        # logger.info("got in try statement")
        # logger.info("got past response")
        logger.info("response")

        score=extract_labels_from_rekognition(response, min_confidence=60)
        result = score_outfit(score, target_context="Formal")
        logger.info(result)

        top_labels = [
            label['Name']
            for label in response['Labels']
            if label['Confidence'] > 60
        ]

        return top_labels

    except ClientError as e:
        logger.error(f"Error detecting labels: {e}")
        return []

def store_clothing_data(img_key, item_data):
    logger.info(boto3.client('sts').get_caller_identity())
    # logger.info("Storing data in DB")
    dynamodb = boto3.resource('dynamodb')
    # logger.info("getting reasource")
    table = dynamodb.Table('clothing-bucket-project')
    # logger.info("getting table")
    table_item_data = ", ".join(item_data)
    logger.info("joining list")
    response = table.put_item(Item={
        "image_key": img_key,
        "item_data": table_item_data
    })
    # logger.info("put in table")

    logger.info(table_item_data)
    return response

def lambda_handler(event, context):
    logger.info("Lambda Handler invoked")
    logger.info(json.dumps(event))

    rekognition = boto3.client('rekognition')
    s3 = boto3.client('s3') 
    sns = boto3.client('sns')
    logger.info("getting rekog")
    logger.info("getting s3")


    record = event['Records'][0]
    bucket_name = record['s3']['bucket']['name']
    image_key = record['s3']['object']['key']
    

    try:
        response = s3.get_object(Bucket=bucket_name, Key=image_key)
        logger.info(response)
        image_bytes = response['Body'].read()
        logger.info("getting reasource")
        top_labels = get_image_labels(rekognition, image_bytes) 
        sns.publish(
            TopicArn="arn:aws:sns:us-east-1:376842762736:imaged",
            Message=json.dumps({
                "image_key": image_key,
                "labels": top_labels
            }),
            Subject="Rekognition Custom Labels Result"
        )
        logger.info(top_labels)
        # logger.info("getting data")
        # reply = store_clothing_data(image_key, top_labels)
        # logger.info(reply)

        result = {
            "ImageKey": image_key,
            "Labels": top_labels
        }
        print(json.dumps(result, indent=2))
        logger.info(result)
        return json.dumps(result, indent=2)

    except ClientError as e:
        logger.error(f"Error processing image {image_key}: {e}")
        raise e