from __future__ import annotations

"""Outfit scoring from Rekognition labels.
Rekognition response
{
    "Labels": [
        {"Name": "Dress", "Confidence": 99.0},
        {"Name": "High Heel", "Confidence": 97.0}
    ],
    "target_weather": "Mild",
    "target_context": "Formal",
    "min_confidence": 80
}

Notes:
- `target_weather` and `target_context` are optional.
- If one or both are missing, the scorer still returns a valid result.
- `mapping_path` can override the bundled CSV path.
"""

import argparse
import csv
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


BUNDLED_MAPPING_PATH = (
    Path(__file__).resolve().parent
    / "AmazonRekognitionLabelsOutfitScoringMapping_v3.0.csv"
)


def resolve_default_mapping_path() -> Path:
    override = os.environ.get("OUTFIT_SCORING_MAPPING_PATH")
    if override:
        return Path(override)
    return BUNDLED_MAPPING_PATH

CORE_ROLE_WEIGHTS = {
    "Top": 35.0,
    "Bottom": 35.0,
    "Shoes": 20.0,
    "FullBody": 70.0,
    "Outerwear": 5.0,
}

BONUS_ROLES = ("Accessory", "Headwear", "Bag")

BASE_FINAL_WEIGHTS = {
    "Completeness": 0.35,
    "WeatherFit": 0.25,
    "ContextFit": 0.25,
    "StyleConsistency": 0.15,
}

WEATHER_ADJACENCY = {
    "Hot": {"Mild", "BeachSummer"},
    "Cold": {"Mild", "Rainy"},
    "Mild": {"Hot", "Cold", "Rainy", "BeachSummer"},
    "Rainy": {"Cold", "Mild"},
    "BeachSummer": {"Hot", "Mild"},
}

CONTEXT_RELATED = {
    "Casual": {"Athletic", "Beach"},
    "Formal": {"Ceremony", "Workwear"},
    "Athletic": {"Casual"},
    "Workwear": {"Utility", "Formal"},
    "Beach": {"Casual"},
    "Sleepwear": set(),
    "Ceremony": {"Formal", "Costume"},
    "Costume": {"Ceremony", "Formal"},
    "Utility": {"Workwear"},
}

CANONICAL_WEATHER = {
    "hot": "Hot",
    "cold": "Cold",
    "mild": "Mild",
    "rainy": "Rainy",
    "beachsummer": "BeachSummer",
    "beach_summer": "BeachSummer",
    "beach-summer": "BeachSummer",
    "allseason": "AllSeason",
    "all_season": "AllSeason",
    "all-season": "AllSeason",
    "na": "NA",
}

CANONICAL_CONTEXT = {
    "casual": "Casual",
    "formal": "Formal",
    "athletic": "Athletic",
    "workwear": "Workwear",
    "beach": "Beach",
    "sleepwear": "Sleepwear",
    "ceremony": "Ceremony",
    "costume": "Costume",
    "utility": "Utility",
    "allpurpose": "AllPurpose",
    "all-purpose": "AllPurpose",
    "all_purpose": "AllPurpose",
    "na": "NA",
}

REKOGNITION_LABEL_KEYS = (
    "Labels",
    "CustomLabels",
    "labels",
    "customLabels",
)

NESTED_REKOGNITION_KEYS = (
    "rekognition_response",
    "rekognition",
    "detect_labels_response",
    "detectLabelsResponse",
)


@dataclass(frozen=True)
class MappingEntry:
    label: str
    item_groups: tuple[str, ...]
    weather_groups: tuple[str, ...]
    context_groups: tuple[str, ...]
    weight: float



def normalize_label(label: str) -> str:
    return " ".join(label.strip().lower().split())


def split_multi_value(raw: str) -> tuple[str, ...]:
    if not raw:
        return ()
    parts = [part.strip() for part in raw.split("|")]
    return tuple(part for part in parts if part and part != "NA")


def scoring_weight(raw: str) -> float:
    lookup = {"Yes": 1.0, "Maybe": 0.5, "No": 0.0}
    if raw not in lookup:
        raise ValueError(f"Unsupported UseForScoring value: {raw}")
    return lookup[raw]


def canonicalize_weather(raw: str | None) -> str | None:
    if raw is None:
        return None
    key = raw.strip().replace(" ", "").lower()
    if not key:
        return None
    return CANONICAL_WEATHER.get(key, raw.strip())


def canonicalize_context(raw: str | None) -> str | None:
    if raw is None:
        return None
    key = raw.strip().replace(" ", "").lower()
    if not key:
        return None
    return CANONICAL_CONTEXT.get(key, raw.strip())


def load_mapping(path: Path) -> dict[str, MappingEntry]:
    if not path.exists():
        raise FileNotFoundError(f"Mapping file not found: {path}")

    entries: dict[str, MappingEntry] = {}
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            label = row["Label"].strip()
            entry = MappingEntry(
                label=label,
                item_groups=split_multi_value(row.get("ItemGroups", "")),
                weather_groups=split_multi_value(row.get("WeatherGroups", "")),
                context_groups=split_multi_value(row.get("ContextGroups", "")),
                weight=scoring_weight(row.get("UseForScoring", "No").strip()),
            )
            entries[normalize_label(label)] = entry
    return entries


def read_labels_file(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        return []
    if path.suffix.lower() == ".json":
        data = json.loads(text)
        if isinstance(data, list):
            return [str(item) for item in data]
        if isinstance(data, dict):
            return extract_labels_from_rekognition(data)
        raise ValueError("JSON labels file must contain a label array or Rekognition response")
    return [line.strip() for line in text.splitlines() if line.strip()]


def labels_from_rekognition_list(items: Iterable[Any], min_confidence: float = 0.0) -> list[str]:
    labels: list[str] = []
    for item in items:
        if isinstance(item, str):
            labels.append(item)
            continue
        if not isinstance(item, dict):
            continue

        name = item.get("Name") or item.get("name") or item.get("Label") or item.get("label")
        if not isinstance(name, str) or not name.strip():
            continue

        confidence = item.get("Confidence", item.get("confidence", 100.0))
        try:
            confidence_value = float(confidence)
        except (TypeError, ValueError):
            confidence_value = 100.0

        if confidence_value >= min_confidence:
            labels.append(name)
    return dedupe_preserve_order(labels)


def extract_labels_from_rekognition(payload: Any, min_confidence: float = 0.0) -> list[str]:
    if isinstance(payload, list):
        return labels_from_rekognition_list(payload, min_confidence=min_confidence)

    if not isinstance(payload, dict):
        return []

    for key in REKOGNITION_LABEL_KEYS:
        value = payload.get(key)
        if isinstance(value, list):
            return labels_from_rekognition_list(value, min_confidence=min_confidence)

    for key in NESTED_REKOGNITION_KEYS:
        nested = payload.get(key)
        labels = extract_labels_from_rekognition(nested, min_confidence=min_confidence)
        if labels:
            return labels

    return []


def labels_from_event(event: dict[str, Any], min_confidence: float = 0.0) -> list[str]:
    labels_value = event.get("labels")
    if isinstance(labels_value, list):
        return labels_from_rekognition_list(labels_value, min_confidence=min_confidence)

    rekognition_payload = event.get("rekognition_response")
    if rekognition_payload is not None:
        return extract_labels_from_rekognition(rekognition_payload, min_confidence=min_confidence)

    labels = extract_labels_from_rekognition(event, min_confidence=min_confidence)
    if labels:
        return labels

    return []


def wants_http_response(event: dict[str, Any]) -> bool:
    return any(
        key in event
        for key in ("httpMethod", "requestContext", "rawPath", "version", "routeKey")
    )


def http_response(status_code: int, payload: dict[str, Any]) -> dict[str, Any]:
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(payload),
    }


def dedupe_preserve_order(labels: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for label in labels:
        normalized = normalize_label(label)
        if normalized in seen:
            continue
        seen.add(normalized)
        ordered.append(label.strip())
    return ordered


def resolve_entries(
    labels: Iterable[str], mapping: dict[str, MappingEntry]
) -> tuple[list[MappingEntry], list[str]]:
    resolved: list[MappingEntry] = []
    unknown: list[str] = []
    for label in labels:
        entry = mapping.get(normalize_label(label))
        if entry is None:
            unknown.append(label)
            continue
        resolved.append(entry)
    return resolved, unknown


def best_weather_multiplier(target_weather: str, groups: tuple[str, ...]) -> float:
    best = 0.0
    for group in groups:
        if group == target_weather:
            best = max(best, 1.0)
        elif group == "AllSeason":
            best = max(best, 0.7)
        elif group in WEATHER_ADJACENCY.get(target_weather, set()):
            best = max(best, 0.5)
    return best


def best_context_multiplier(target_context: str, groups: tuple[str, ...]) -> float:
    best = 0.0
    for group in groups:
        if group == target_context:
            best = max(best, 1.0)
        elif group == "AllPurpose":
            best = max(best, 0.7)
        elif group in CONTEXT_RELATED.get(target_context, set()):
            best = max(best, 0.5)
    return best


def role_strengths(entries: Iterable[MappingEntry]) -> dict[str, float]:
    strengths = {role: 0.0 for role in (*CORE_ROLE_WEIGHTS, *BONUS_ROLES)}
    for entry in entries:
        if entry.weight <= 0:
            continue
        for group in entry.item_groups:
            if group in strengths:
                strengths[group] = max(strengths[group], entry.weight)
    return strengths


def completeness_score(entries: Iterable[MappingEntry]) -> tuple[float, dict[str, float], str]:
    strengths = role_strengths(entries)
    has_full_body = strengths["FullBody"] > 0
    bonus_strength = max(strengths[role] for role in BONUS_ROLES)

    if has_full_body:
        score = (
            CORE_ROLE_WEIGHTS["FullBody"] * strengths["FullBody"]
            + CORE_ROLE_WEIGHTS["Shoes"] * strengths["Shoes"]
            + CORE_ROLE_WEIGHTS["Outerwear"] * strengths["Outerwear"]
            + 5.0 * bonus_strength
        )
        mode = "full-body"
    else:
        score = (
            CORE_ROLE_WEIGHTS["Top"] * strengths["Top"]
            + CORE_ROLE_WEIGHTS["Bottom"] * strengths["Bottom"]
            + CORE_ROLE_WEIGHTS["Shoes"] * strengths["Shoes"]
            + CORE_ROLE_WEIGHTS["Outerwear"] * strengths["Outerwear"]
            + 5.0 * bonus_strength
        )
        mode = "separates"

    return min(score, 100.0), strengths, mode


def compatibility_score(
    entries: Iterable[MappingEntry],
    target: str | None,
    mode: str,
) -> tuple[float | None, float, float]:
    if target is None:
        return None, 0.0, 0.0

    earned = 0.0
    possible = 0.0
    for entry in entries:
        if entry.weight <= 0:
            continue
        possible += entry.weight
        if mode == "weather":
            earned += entry.weight * best_weather_multiplier(target, entry.weather_groups)
        else:
            earned += entry.weight * best_context_multiplier(target, entry.context_groups)

    if possible == 0:
        return 0.0, 0.0, 0.0
    return (100.0 * earned / possible), earned, possible


def style_consistency_score(entries: Iterable[MappingEntry]) -> tuple[float, dict[str, float]]:
    evidence: dict[str, float] = {}
    total_specific_weight = 0.0

    for entry in entries:
        if entry.weight <= 0:
            continue

        specific_contexts = [
            group
            for group in entry.context_groups
            if group not in {"AllPurpose", "NA"}
        ]
        if not specific_contexts:
            continue

        share = entry.weight / len(specific_contexts)
        for context in specific_contexts:
            evidence[context] = evidence.get(context, 0.0) + share
        total_specific_weight += entry.weight

    if total_specific_weight == 0:
        return 100.0, {}

    strongest = max(evidence.values(), default=0.0)
    return 100.0 * strongest / total_specific_weight, evidence


def final_score(
    completeness: float,
    weather_fit: float | None,
    context_fit: float | None,
    style_consistency: float,
) -> float:
    if weather_fit is None and context_fit is None:
        return 0.55 * completeness + 0.45 * style_consistency

    components = {
        "Completeness": completeness,
        "StyleConsistency": style_consistency,
    }
    weights = {
        "Completeness": BASE_FINAL_WEIGHTS["Completeness"],
        "StyleConsistency": BASE_FINAL_WEIGHTS["StyleConsistency"],
    }

    if weather_fit is not None:
        components["WeatherFit"] = weather_fit
        weights["WeatherFit"] = BASE_FINAL_WEIGHTS["WeatherFit"]
    if context_fit is not None:
        components["ContextFit"] = context_fit
        weights["ContextFit"] = BASE_FINAL_WEIGHTS["ContextFit"]

    total_weight = sum(weights.values())
    return sum(components[name] * weights[name] for name in components) / total_weight


def round_score(value: float | None) -> float | None:
    if value is None:
        return None
    return round(value, 2)


def score_outfit(
    labels: Iterable[str],
    mapping_path: Path | None = None,
    target_weather: str | None = None,
    target_context: str | None = None,
) -> dict:
    if mapping_path is None:
        mapping_path = resolve_default_mapping_path()

    cleaned_labels = dedupe_preserve_order(labels)
    mapping = load_mapping(mapping_path)
    entries, unknown_labels = resolve_entries(cleaned_labels, mapping)

    completeness, strengths, outfit_mode = completeness_score(entries)
    weather_target = canonicalize_weather(target_weather)
    context_target = canonicalize_context(target_context)

    weather_fit, weather_earned, weather_possible = compatibility_score(
        entries, weather_target, mode="weather"
    )
    context_fit, context_earned, context_possible = compatibility_score(
        entries, context_target, mode="context"
    )
    style_consistency, context_evidence = style_consistency_score(entries)

    score = final_score(completeness, weather_fit, context_fit, style_consistency)

    return {
        "input_labels": cleaned_labels,
        "recognized_labels": [entry.label for entry in entries],
        "unknown_labels": unknown_labels,
        "mapping_path": str(mapping_path),
        "outfit_mode": outfit_mode,
        "target_weather": weather_target,
        "target_context": context_target,
        "role_strengths": {key: round(value, 2) for key, value in strengths.items()},
        "context_evidence": {
            key: round(value, 2)
            for key, value in sorted(context_evidence.items(), key=lambda item: (-item[1], item[0]))
        },
        "scores": {
            "Completeness": round_score(completeness),
            "WeatherFit": round_score(weather_fit),
            "ContextFit": round_score(context_fit),
            "StyleConsistency": round_score(style_consistency),
            "FinalScore": round_score(score),
        },
        "debug": {
            "weather_points": {
                "earned": round(weather_earned, 4),
                "possible": round(weather_possible, 4),
            },
            "context_points": {
                "earned": round(context_earned, 4),
                "possible": round(context_possible, 4),
            },
        },
    }

