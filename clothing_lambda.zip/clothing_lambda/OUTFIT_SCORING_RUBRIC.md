# Outfit Scoring Rubric

Use this rubric with `AmazonRekognitionLabelsOutfitScoringMapping_v3.0.csv`.

The mapping is multi-tag.

- `ItemGroups`, `WeatherGroups`, and `ContextGroups` can contain multiple values.
- Multiple values are separated by `|`.
- A label can activate more than one bucket at the same time.
- Example: `Blazer -> Top|Outerwear`, `Dress -> Casual|Formal|Ceremony`.

## 1. Inputs

- Detected labels from Rekognition.
- Optional target weather: `Hot`, `Cold`, `Mild`, `Rainy`, `BeachSummer`.
- Optional target context: `Casual`, `Formal`, `Athletic`, `Workwear`, `Beach`, `Sleepwear`, `Ceremony`, `Costume`.

## 2. Label Filtering

- Ignore rows where `UseForScoring=No`.
- Use full weight for rows where `UseForScoring=Yes`.
- Use half weight for rows where `UseForScoring=Maybe`.
- Split multi-value columns on `|` before scoring.
- For weather and context matching, use the best matching tag for each label instead of adding the same label multiple times.

Suggested weight mapping:

- `Yes = 1.0`
- `Maybe = 0.5`
- `No = 0.0`

## 3. Core Outfit Roles

Collapse detected labels into these outfit roles:

- `Top`: `ItemGroups` contains `Top`
- `Bottom`: `ItemGroups` contains `Bottom`
- `Shoes`: `ItemGroups` contains `Shoes`
- `FullBody`: `ItemGroups` contains `FullBody`
- `Outerwear`: `ItemGroups` contains `Outerwear`
- `Accessory`: `ItemGroups` contains `Accessory`
- `Headwear`: `ItemGroups` contains `Headwear`
- `Bag`: `ItemGroups` contains `Bag`

Important:

- Multi-tag labels should only toggle presence for a role, not stack duplicate completeness points.
- Example: a `Blazer` can satisfy both `Top` and `Outerwear`, but it should not count as two separate garments.
- For completeness, treat each role as boolean present or absent.
- If a role is supported only by weak labels, you can scale that role by label confidence or by `UseForScoring` weight.

## 4. Completeness Score

Score from `0-100`.

### Separate outfit logic

Use when no `FullBody` item is present.

- `Top present`: +35
- `Bottom present`: +35
- `Shoes present`: +20
- `Outerwear present`: +5
- `Accessory or Headwear or Bag present`: +5 total

Cap at `100`.

### Full-body outfit logic

Use when any `FullBody` item is present.

- `FullBody present`: +70
- `Shoes present`: +20
- `Outerwear present`: +5
- `Accessory or Headwear or Bag present`: +5 total

Cap at `100`.

Interpretation:

- `90-100`: complete outfit
- `70-89`: mostly complete
- `40-69`: partial outfit
- `<40`: weak outfit evidence

## 5. Weather Fit Score

Score from `0-100` against a target weather.

For each detected label used in scoring:

- exact weather match on any tag: `+1.0 * weight`
- `AllSeason` on any tag with any target: `+0.7 * weight`
- adjacent weather match on any tag: `+0.5 * weight`
- obvious mismatch across all tags: `0`
- use only the best weather match per label, even if multiple tags match

Suggested adjacent matches:

- `Mild` works partially for `Hot` and `Cold`
- `BeachSummer` works for `Hot`
- `Cold` outerwear can partially support `Rainy`

Normalize as:

`WeatherFit = 100 * earned_points / max_possible_points`

Weather heuristics:

- Penalize `Hot` targets if heavy cold items dominate: `Coat`, `Overcoat`, `Boot`, `Sweater`, `Sweatshirt`
- Penalize `Cold` targets if only light summer items are present: `Bikini`, `Tank Top`, `Shorts`, `Flip-Flop`, `Swimwear`
- Reward `Rainy` targets for `Raincoat`, `Trench Coat`, `Poncho`, `Boot`

## 6. Context Fit Score

Score from `0-100` against a target context.

For each detected label used in scoring:

- exact context match on any tag: `+1.0 * weight`
- `AllPurpose` on any tag with any target: `+0.7 * weight`
- related context match on any tag: `+0.5 * weight`
- mismatch across all tags: `0`
- use only the best context match per label, even if multiple tags match

Suggested related matches:

- `Formal` and `Ceremony`
- `Casual` and `AllPurpose`
- `Athletic` and `Casual`
- `Workwear` and `Utility`

Normalize as:

`ContextFit = 100 * earned_points / max_possible_points`

Context anchors:

- Formal signals: `Blazer`, `Dress Shirt`, `Evening Dress`, `Gown`, `High Heel`, `Necktie`, `Suit`, `Tie`, `Tuxedo`
- Casual signals: `Baseball Cap`, `Hoodie`, `Jeans`, `Sneaker`, `Sweater`, `T-Shirt`
- Athletic signals: `Jersey`, `Running Shoe`, `Ski Boot`
- Beach signals: `Bikini`, `Beachwear`, `Flip-Flop`, `Sun Hat`, `Swimming Trunks`, `Swimwear`
- Ceremony signals: `Bridal Veil`, `Crown`, `Sari`, `Tiara`, `Veil`, `Wedding Gown`

## 7. Style Consistency Score

Score from `0-100`.

Measure how concentrated the outfit is around one context.

1. Split each label's `ContextGroups` on `|`.
2. Split the label's weight evenly across its specific context buckets.
3. Take the strongest context bucket total.
4. Divide by total weighted context evidence.

`StyleConsistency = 100 * strongest_context_weight / total_context_weight`

Interpretation:

- `80-100`: highly coherent
- `60-79`: mostly coherent
- `<60`: mixed signals

Examples of inconsistency:

- `Tuxedo` with `Flip-Flop`
- `Evening Dress` with `Baseball Cap`
- `Raincoat` with `Bikini` outside beach context

## 8. Final Score

Recommended weighted total:

`FinalScore = 0.35 * Completeness + 0.25 * WeatherFit + 0.25 * ContextFit + 0.15 * StyleConsistency`

If no target weather or target context is supplied, use:

- `FinalScore = 0.55 * Completeness + 0.45 * StyleConsistency`

## 9. Practical Defaults

If you need a simple production rule set:

- A strong outfit needs either:
  - `Top + Bottom + Shoes`, or
  - `FullBody + Shoes`
- Ignore `MaterialPart`, `Beauty`, `Protective`, and `Generic` unless you want style modifiers.
- Use `Accessory`, `Headwear`, and `Bag` only as bonus signals, not core outfit requirements.
- Treat `Swimwear` and `Sleepwear` as special contexts, not normal daily outfits.

## 10. Minimal Implementation Order

Start with these steps:

1. Filter labels by `UseForScoring`.
2. Detect whether the outfit is `separates` or `full-body`.
3. Compute `Completeness`.
4. If a target weather exists, compute `WeatherFit`.
5. If a target context exists, compute `ContextFit`.
6. Compute `StyleConsistency`.
7. Combine into `FinalScore`.